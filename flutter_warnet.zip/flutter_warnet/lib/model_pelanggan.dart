class Pelanggan {
  String kodePelanggan;
  String namaPelanggan;
  String jenisPelanggan;
  int jamMasuk;
  int jamKeluar;
  int tarifPerJam;
  DateTime tglMasuk;
  double diskon = 0.0;
  double totalBayar = 0.0;

  Pelanggan({
    required this.kodePelanggan,
    required this.namaPelanggan,
    required this.jenisPelanggan,
    required this.jamMasuk,
    required this.jamKeluar,
    required this.tarifPerJam,
    required this.tglMasuk,
  }) {
    _hitungTotalBayar();
  }

  void _hitungTotalBayar() {
    int lama = jamKeluar - jamMasuk;

    if (lama < 0) {
      // Validasi jam
      print('Jam Keluar tidak boleh lebih kecil dari Jam Masuk!');
      totalBayar =
          0.0; // Set total bayar ke 0 jika jam keluar lebih kecil dari jam masuk
      return;
    }

    if (jenisPelanggan == "VIP" && lama > 2) {
      diskon = 0.02 * tarifPerJam * lama;
    } else if (jenisPelanggan == "GOLD" && lama > 2) {
      diskon = 0.05 * tarifPerJam * lama;
    }

    totalBayar = (lama * tarifPerJam) - diskon;

    // Debug output untuk mengecek perhitungan
    print('Lama: $lama, Diskon: $diskon, Total Bayar: $totalBayar');
  }
}
