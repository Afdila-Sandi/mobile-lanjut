import 'package:flutter/material.dart';
import 'model_pelanggan.dart';

class EntryForm extends StatefulWidget {
  @override
  _EntryFormState createState() => _EntryFormState();
}

class _EntryFormState extends State<EntryForm> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController kodePelangganController = TextEditingController();
  final TextEditingController namaPelangganController = TextEditingController();
  String jenisPelanggan = 'VIP'; // Default value for dropdown
  final TextEditingController jamMasukController = TextEditingController();
  final TextEditingController jamKeluarController = TextEditingController();
  DateTime selectedDate = DateTime.now();

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2021),
      lastDate: DateTime(2025),
    );
    if (picked != null && picked != selectedDate)
      setState(() {
        selectedDate = picked;
      });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Form Pelanggan'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: <Widget>[
              TextFormField(
                controller: kodePelangganController,
                decoration: InputDecoration(labelText: 'Kode Pelanggan'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Masukkan Kode Pelanggan';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: namaPelangganController,
                decoration: InputDecoration(labelText: 'Nama Pelanggan'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Masukkan Nama Pelanggan';
                  }
                  return null;
                },
              ),
              DropdownButtonFormField<String>(
                value: jenisPelanggan,
                onChanged: (String? newValue) {
                  setState(() {
                    jenisPelanggan = newValue!;
                  });
                },
                decoration: InputDecoration(labelText: 'Jenis Pelanggan'),
                items: <String>['VIP', 'GOLD']
                    .map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
              TextFormField(
                controller: jamMasukController,
                decoration: InputDecoration(labelText: 'Jam Masuk (misal: 10)'),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Masukkan Jam Masuk';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: jamKeluarController,
                decoration: InputDecoration(labelText: 'Jam Keluar (misal: 13)'),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Masukkan Jam Keluar';
                  }
                  return null;
                },
              ),
              Row(
                children: <Widget>[
                  Text("Tanggal Masuk: ${selectedDate.toLocal()}".split(' ')[0]),
                  SizedBox(width: 10),
                  ElevatedButton(
                    onPressed: () => _selectDate(context),
                    child: Text('Pilih Tanggal'),
                  ),
                ],
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    Pelanggan pelanggan = Pelanggan(
                      kodePelanggan: kodePelangganController.text,
                      namaPelanggan: namaPelangganController.text,
                      jenisPelanggan: jenisPelanggan,
                      jamMasuk: int.parse(jamMasukController.text),
                      jamKeluar: int.parse(jamKeluarController.text),
                      tarifPerJam: 10000, // Tarif tetap
                      tglMasuk: selectedDate,
                    );

                    // Debug output to check the created customer object
                    print('Pelanggan Created: ${pelanggan.namaPelanggan}, ${pelanggan.jenisPelanggan}, ${pelanggan.jamMasuk}, ${pelanggan.jamKeluar}, ${pelanggan.totalBayar}');

                    Navigator.pop(context, pelanggan); // Mengirim data kembali
                  }
                },
                child: Text('Simpan'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
