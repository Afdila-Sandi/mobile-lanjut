import 'package:flutter/material.dart';
import 'entry_form.dart';
import 'model_pelanggan.dart';
import 'detail_pelanggan.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aplikasi Warnet',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<Pelanggan> pelangganList = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Aplikasi Warnet'),
      ),
      body: ListView.builder(
        itemCount: pelangganList.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(pelangganList[index].namaPelanggan),
            subtitle: Text(
                'Total Bayar: Rp${pelangganList[index].totalBayar.toStringAsFixed(2)}'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      DetailPelanggan(pelanggan: pelangganList[index]),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => EntryForm()),
          );
          if (result != null) {
            setState(() {
              pelangganList.add(result);
            });
          }
        },
        tooltip: 'Tambah Pelanggan',
        child: Icon(Icons.add),
      ),
    );
  }
}
