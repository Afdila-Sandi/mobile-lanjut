import 'package:flutter/material.dart';
import 'model_pelanggan.dart';

class DetailPelanggan extends StatelessWidget {
  final Pelanggan pelanggan;

  DetailPelanggan({required this.pelanggan}) {
    // Debug output to check received customer data
    print(
        'Received Pelanggan: ${pelanggan.namaPelanggan}, ${pelanggan.jenisPelanggan}, ${pelanggan.jamMasuk}, ${pelanggan.jamKeluar}, ${pelanggan.totalBayar}');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail Pelanggan'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Nama Pelanggan: ${pelanggan.namaPelanggan}',
                style: TextStyle(fontSize: 18)),
            Text('Jenis Pelanggan: ${pelanggan.jenisPelanggan}',
                style: TextStyle(fontSize: 18)),
            Text('Tanggal Masuk: ${pelanggan.tglMasuk.toLocal()}'.split(' ')[0],
                style: TextStyle(fontSize: 18)),
            Text('Jam Masuk: ${pelanggan.jamMasuk}',
                style: TextStyle(fontSize: 18)),
            Text('Jam Keluar: ${pelanggan.jamKeluar}',
                style: TextStyle(fontSize: 18)),
            Text('Tarif: Rp${pelanggan.tarifPerJam}',
                style: TextStyle(fontSize: 18)),
            Text('Diskon: Rp${pelanggan.diskon.toStringAsFixed(2)}',
                style: TextStyle(fontSize: 18)),
            Text('Total Bayar: Rp${pelanggan.totalBayar.toStringAsFixed(2)}',
                style: TextStyle(fontSize: 18)),
          ],
        ),
      ),
    );
  }
}
